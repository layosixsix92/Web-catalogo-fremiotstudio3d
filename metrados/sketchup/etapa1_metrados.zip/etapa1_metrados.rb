require 'sketchup.rb'
require 'extensions.rb'
ext = SketchupExtension.new('Etapa 1 - Metrados', 'etapa1_metrados/main')
ext.description = 'Modelo de verificación de metrados de la Etapa 1 (cimentación, columnas, cerco y muros).'
ext.version = '1.0'
ext.creator = 'Fremiot HQ'
Sketchup.register_extension(ext, true)
